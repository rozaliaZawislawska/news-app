package com.basic.newsapp.viewModel

import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.basic.newsapp.model.Article
import com.basic.newsapp.util.parseRss
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase
import com.google.firebase.database.ktx.database
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.net.URL


class ArticleViewModel : ViewModel() {

    private val rssUrl = "https://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.xml"
    private val database = Firebase.database.reference
    private val currentUserId = "testUser123"

    private val _rawArticlesFlow = MutableStateFlow<List<Article>>(emptyList())

    private val _selectedTabIndex = MutableStateFlow(0)
    val selectedTabIndex = _selectedTabIndex.asStateFlow()

    fun selectTab(index: Int) {
        _selectedTabIndex.value = index
    }

    fun fetchArticles() {
        viewModelScope.launch {
            try {
                // `withContext(Dispatchers.IO)` jest potrzebne do operacji sieciowych
                val parsedArticles = withContext(Dispatchers.IO) {
                    val inputStream = URL(rssUrl).openStream()
                    parseRss(inputStream)
                    }
                    val cleanedArticles = parsedArticles.map { article ->
                        article.copy(
                            content = Jsoup.parse(article.content).text()
                        )
                    }

                    _rawArticlesFlow.value = cleanedArticles

                _rawArticlesFlow.value = parsedArticles
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private val visitedArticlesFlow: StateFlow<Set<String>> = callbackFlow<Set<String>> {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val guids = snapshot.children.mapNotNull { it.key }.toSet()
                trySend(guids)
            }
            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        val userVisitedRef = database.child("users").child(currentUserId).child("visitedArticles")
        userVisitedRef.addValueEventListener(listener)
        awaitClose { userVisitedRef.removeEventListener(listener) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    fun markArticleAsVisited(article: Article) {
        if (article.guid.isBlank()) return

        val safeKey = Base64.encodeToString(
            article.guid.toByteArray(),
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
        )

        database.child("users").child(currentUserId).child("visitedArticles")
            .child(safeKey)
            .setValue(true)
    }

    private val favoriteArticlesFlow: StateFlow<Set<String>> = callbackFlow<Set<String>> {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val guids = snapshot.children.mapNotNull { it.key }.toSet()
                trySend(guids)
            }
            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        val userVisitedRef = database.child("users").child(currentUserId).child("favoriteArticles")
        userVisitedRef.addValueEventListener(listener)
        awaitClose { userVisitedRef.removeEventListener(listener) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())


    fun markArticleAsFavorite(article: Article) {
        if (article.guid.isBlank()) return

        val safeKey = Base64.encodeToString(
            article.guid.toByteArray(),
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
        )

        val articleRef = database.child("users").child(currentUserId).child("favoriteArticles")
            .child(safeKey)

        if (article.isFavorite) {
            articleRef.removeValue()
        } else {
            articleRef.setValue(true)
        }
    }
    val uiState: StateFlow<ArticleUiState> = combine(
        _rawArticlesFlow,
        visitedArticlesFlow,
        favoriteArticlesFlow,
        selectedTabIndex
    ) { articles, visitedGuids, favoritesArticles, tabIndex  ->
        if (articles.isEmpty()) {
            ArticleUiState.Loading
        } else {
            val articlesWithStatus = articles.map { article ->
                val safeKey = Base64.encodeToString(
                    article.guid.toByteArray(),
                    Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
                )

                val isVisited = safeKey in visitedGuids
                val isFavorite = safeKey in favoritesArticles

                article.copy(isVisited = isVisited)
                article.copy(isFavorite = isFavorite)
            }

            val filteredArticles = if (tabIndex == 1) {
                articlesWithStatus.filter { it.isFavorite }
            } else {
                articlesWithStatus
            }

            ArticleUiState.Success(filteredArticles)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ArticleUiState.Loading
    )
}

sealed interface ArticleUiState {
    data object Loading : ArticleUiState
    data class Success(val articles: List<Article>) : ArticleUiState
    data class Error(val message: String) : ArticleUiState
}